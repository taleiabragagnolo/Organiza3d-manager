const STORE_KEY = 'organiza3d-manager-v1';
const defaultData = {
  printers: [], materials: [], products: [], batches: [], failures: [], orders: [], transactions: [], settings: { company:'Organiza 3D Home e Kids', kwh:0.95 }
};
let data = loadData();
let route = 'dashboard';
const content = document.querySelector('#content');
const title = document.querySelector('#page-title');
const modal = document.querySelector('#modal');
const modalTitle = document.querySelector('#modal-title');
const modalBody = document.querySelector('#modal-body');
const modalForm = document.querySelector('#modal-form');
let onSave = null;

function loadData(){
  try { return {...defaultData, ...(JSON.parse(localStorage.getItem(STORE_KEY)) || {})}; }
  catch { return structuredClone(defaultData); }
}
function saveData(){ localStorage.setItem(STORE_KEY, JSON.stringify(data)); render(); }
function money(v){ return Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }
function pct(v){ return `${Number(v||0).toFixed(1).replace('.',',')}%`; }
function uid(){ return crypto.randomUUID ? crypto.randomUUID() : String(Date.now()+Math.random()); }
function esc(s=''){ return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function sum(arr, fn){ return arr.reduce((a,x)=>a+Number(fn(x)||0),0); }
function today(){ return new Date().toISOString().slice(0,10); }

const routes = {
  dashboard:{title:'Início', render:dashboardView, add:null},
  production:{title:'Produção', render:productionView, add:()=>openBatchForm()},
  inventory:{title:'Estoque', render:inventoryView, add:()=>openMaterialForm()},
  finance:{title:'Financeiro', render:financeView, add:()=>openTransactionForm()},
  more:{title:'Mais', render:moreView, add:null},
  printers:{title:'Impressoras', render:printersView, add:()=>openPrinterForm()},
  products:{title:'Produtos', render:productsView, add:()=>openProductForm()},
  orders:{title:'Encomendas', render:ordersView, add:()=>openOrderForm()},
  failures:{title:'Falhas', render:failuresView, add:()=>openFailureForm()},
  settings:{title:'Configurações', render:settingsView, add:null}
};

function navigate(next){ route=next; document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.route===next)); render(); }
function render(){ const cfg=routes[route]||routes.dashboard; title.textContent=cfg.title; document.querySelector('#quick-add').style.visibility=cfg.add?'visible':'hidden'; content.innerHTML=cfg.render(); bindDynamic(); }

function dashboardView(){
  const invested = sum(data.printers,p=>p.value)+sum(data.transactions,t=>t.type==='saida'?t.value:0);
  const revenue = sum(data.transactions,t=>t.type==='entrada'?t.value:0);
  const expenses = sum(data.transactions,t=>t.type==='saida'?t.value:0)+sum(data.failures,f=>f.cost);
  const profit = revenue-expenses;
  const produced = sum(data.batches,b=>b.goodQty);
  const failed = sum(data.failures,f=>f.qty);
  const failRate = produced+failed ? failed/(produced+failed)*100 : 0;
  const recovery = invested>0 ? Math.min(100,Math.max(0,revenue/invested*100)) : 0;
  return `
    <section class="hero"><h2>Resultado acumulado</h2><strong>${money(profit)}</strong><p>${profit>=0?'Sua operação está positiva.':'As despesas ainda superam as entradas.'}</p><div class="progress"><i style="width:${recovery}%"></i></div><p>${pct(recovery)} do investimento recuperado</p></section>
    <div class="grid cols-4">
      ${metric('Faturamento',money(revenue),'positive')}${metric('Despesas',money(expenses),'negative')}${metric('Produzidas',produced)}${metric('Falhas',pct(failRate),failRate>5?'negative':'positive')}
    </div>
    <div class="quick-grid">
      ${quick('Nova venda','Registrar entrada financeira','transaction')}${quick('Nova produção','Criar lote de produção','batch')}${quick('Nova encomenda','Cadastrar pedido de cliente','order')}${quick('Registrar falha','Contabilizar perda','failure')}
    </div>
    ${section('Encomendas em aberto', openOrdersList())}
    ${section('Alertas de estoque', lowStockList())}`;
}
function metric(label,value,cls=''){ return `<div class="card"><h3 class="muted">${label}</h3><div class="metric ${cls}">${value}</div></div>`; }
function quick(a,b,type){ return `<button class="quick" data-quick="${type}"><strong>${a}</strong><span class="muted">${b}</span></button>`; }
function section(name,body){ return `<div class="section-title"><h2>${name}</h2></div>${body}`; }
function empty(){ return `<section class="empty-state"><div class="empty-icon">◎</div><h3>Nenhum registro ainda</h3><p>Use o botão “＋” para começar.</p></section>`; }
function openOrdersList(){ const arr=data.orders.filter(o=>!['Entregue','Cancelado'].includes(o.status)).slice(0,5); return arr.length?`<div class="list">${arr.map(o=>listItem(esc(o.customer),`${esc(o.product)} • entrega ${fmtDate(o.due)}`,o.status)).join('')}</div>`:empty(); }
function lowStockList(){ const arr=data.materials.filter(m=>Number(m.qty)<=Number(m.min||0)); return arr.length?`<div class="list">${arr.map(m=>listItem(esc(m.name),`${m.qty} ${esc(m.unit)} disponíveis`,'Estoque baixo','danger')).join('')}</div>`:`<div class="card positive">Nenhum material abaixo do estoque mínimo.</div>`; }
function listItem(name,desc,badge,kind=''){ return `<div class="list-item"><div class="list-main"><h4>${name}</h4><p>${desc}</p></div>${badge?`<span class="badge ${kind}">${esc(badge)}</span>`:''}</div>`; }
function fmtDate(d){ if(!d)return '—'; const [y,m,day]=d.split('-'); return `${day}/${m}/${y}`; }

function productionView(){
  const batches = data.batches.slice().reverse();
  const successQty=sum(batches,b=>b.goodQty), failQty=sum(data.failures,f=>f.qty); const rate=(successQty+failQty)?successQty/(successQty+failQty)*100:0;
  return `<div class="grid">${metric('Lotes',batches.length)}${metric('Taxa de sucesso',pct(rate),rate>=95?'positive':'warning')}</div>${section('Lotes de produção',batches.length?`<div class="list">${batches.map(b=>listItem(esc(productName(b.productId)),`${b.goodQty} boas • custo ${money(b.totalCost)}`,fmtDate(b.date))).join('')}</div>`:empty())}`;
}
function inventoryView(){
  const stockValue=sum(data.materials,m=>m.qty*m.unitCost)+sum(data.products,p=>p.stock*p.cost);
  return `${metric('Valor estimado em estoque',money(stockValue))}${section('Matérias-primas',data.materials.length?`<div class="list">${data.materials.map(m=>listItem(esc(m.name),`${m.qty} ${esc(m.unit)} • ${money(m.unitCost)}/${esc(m.unit)}`,m.qty<=m.min?'Baixo':'OK',m.qty<=m.min?'danger':'success')).join('')}</div>`:empty())}${section('Produtos acabados',data.products.length?`<div class="list">${data.products.map(p=>listItem(esc(p.name),`${p.stock} un. • venda ${money(p.price)}`,money(p.stock*p.cost))).join('')}</div>`:empty())}`;
}
function financeView(){
  const ins=sum(data.transactions,t=>t.type==='entrada'?t.value:0), outs=sum(data.transactions,t=>t.type==='saida'?t.value:0), fail=sum(data.failures,f=>f.cost);
  const tx=data.transactions.slice().reverse();
  return `<div class="grid">${metric('Entradas',money(ins),'positive')}${metric('Saídas + falhas',money(outs+fail),'negative')}</div>${section('Movimentações',tx.length?`<div class="list">${tx.map(t=>listItem(esc(t.description),fmtDate(t.date),`${t.type==='entrada'?'+':'-'} ${money(t.value)}`,t.type==='entrada'?'success':'danger')).join('')}</div>`:empty())}`;
}
function moreView(){ return `<div class="menu-list">
  ${menu('Impressoras','Equipamentos, custos e manutenção','printers')}${menu('Produtos','Receitas, preços e estoque','products')}${menu('Encomendas','Pedidos, prazos e pagamentos','orders')}${menu('Falhas','Perdas, causas e despesas','failures')}${menu('Configurações e backup','Energia, exportação e restauração','settings')}
</div>`; }
function menu(a,b,r){ return `<button class="menu-btn" data-nav="${r}"><span><strong>${a}</strong><small>${b}</small></span><span>›</span></button>`; }
function printersView(){ return data.printers.length?`<div class="list">${data.printers.map(p=>listItem(esc(p.name),`${esc(p.model)} • comprada em ${fmtDate(p.date)}`,money(p.value))).join('')}</div>`:empty(); }
function productsView(){ return data.products.length?`<div class="list">${data.products.map(p=>listItem(esc(p.name),`Custo ${money(p.cost)} • Estoque ${p.stock}`,money(p.price))).join('')}</div>`:empty(); }
function ordersView(){ return data.orders.length?`<div class="list">${data.orders.slice().reverse().map(o=>listItem(esc(o.customer),`${esc(o.product)} • ${money(o.total)} • saldo ${money(o.total-o.paid)}`,o.status)).join('')}</div>`:empty(); }
function failuresView(){ const cost=sum(data.failures,f=>f.cost); return `${metric('Despesa com falhas',money(cost),'negative')}${data.failures.length?`<div class="list" style="margin-top:14px">${data.failures.slice().reverse().map(f=>listItem(esc(productName(f.productId)),`${f.qty} un. • ${esc(f.reason)}`,money(f.cost),'danger')).join('')}</div>`:empty()}`; }
function settingsView(){ return `<div class="card"><div class="field"><label>Valor do kWh</label><input id="setting-kwh" type="number" step="0.01" value="${data.settings.kwh}"></div><button class="btn primary" data-action="save-settings">Salvar configuração</button></div>
  <div class="section-title"><h2>Backup</h2></div><div class="actions-row"><button class="btn secondary" data-action="export">Exportar dados</button><label class="btn secondary">Importar dados<input id="import-file" type="file" accept="application/json" hidden></label><button class="btn danger" data-action="reset">Apagar dados</button></div>
  <p class="muted">Os dados ficam armazenados neste aparelho/navegador. Faça backups periódicos.</p>`; }

function bindDynamic(){
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>navigate(b.dataset.nav));
  document.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>({transaction:openTransactionForm,batch:openBatchForm,order:openOrderForm,failure:openFailureForm}[b.dataset.quick])());
  document.querySelector('[data-action="save-settings"]')?.addEventListener('click',()=>{data.settings.kwh=Number(document.querySelector('#setting-kwh').value||0);saveData();});
  document.querySelector('[data-action="export"]')?.addEventListener('click',exportData);
  document.querySelector('#import-file')?.addEventListener('change',importData);
  document.querySelector('[data-action="reset"]')?.addEventListener('click',()=>{if(confirm('Apagar todos os dados?')){data=structuredClone(defaultData);saveData();}});
}

function openModal(titleText, body, saveFn){ modalTitle.textContent=titleText; modalBody.innerHTML=body; onSave=saveFn; modal.showModal(); }
modalForm.addEventListener('submit',e=>{ if(e.submitter?.value==='cancel')return; e.preventDefault(); try{ onSave?.(new FormData(modalForm)); modal.close(); saveData(); } catch(err){ alert(err.message||'Revise os campos.'); }});
document.querySelector('#quick-add').onclick=()=>routes[route].add?.();

document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>navigate(b.dataset.route));

const field=(label,name,type='text',extra='')=>`<div class="field"><label>${label}</label><input name="${name}" type="${type}" ${extra} required></div>`;
const select=(label,name,options)=>`<div class="field"><label>${label}</label><select name="${name}" required>${options.map(([v,l])=>`<option value="${v}">${l}</option>`).join('')}</select></div>`;
function openPrinterForm(){ openModal('Nova impressora',`${field('Nome interno','name')}${field('Marca/modelo','model')}${field('Data da compra','date','date',`value="${today()}"`)}${field('Valor da compra','value','number','step="0.01" min="0"')}`,fd=>data.printers.push({id:uid(),name:fd.get('name'),model:fd.get('model'),date:fd.get('date'),value:Number(fd.get('value'))})); }
function openMaterialForm(){ openModal('Nova matéria-prima',`${field('Nome','name')}${select('Categoria','category',[['Filamento','Filamento'],['Acessório','Acessório'],['Embalagem','Embalagem'],['Manutenção','Manutenção']])}<div class="field-row">${field('Quantidade','qty','number','step="0.01" min="0"')}${field('Unidade','unit','text','placeholder="g, un., ml..."')}</div><div class="field-row">${field('Custo por unidade','unitCost','number','step="0.0001" min="0"')}${field('Estoque mínimo','min','number','step="0.01" min="0"')}</div>`,fd=>data.materials.push({id:uid(),name:fd.get('name'),category:fd.get('category'),qty:Number(fd.get('qty')),unit:fd.get('unit'),unitCost:Number(fd.get('unitCost')),min:Number(fd.get('min'))})); }
function openProductForm(){ openModal('Novo produto',`${field('Nome do produto','name')}${field('Custo unitário estimado','cost','number','step="0.01" min="0"')}${field('Preço de venda','price','number','step="0.01" min="0"')}${field('Estoque inicial','stock','number','step="1" min="0"')}${field('Tempo de impressão em minutos','minutes','number','step="1" min="0"')}`,fd=>data.products.push({id:uid(),name:fd.get('name'),cost:Number(fd.get('cost')),price:Number(fd.get('price')),stock:Number(fd.get('stock')),minutes:Number(fd.get('minutes'))})); }
function openBatchForm(){ if(!data.products.length) return alert('Cadastre um produto primeiro.'); openModal('Novo lote',`${select('Produto','productId',data.products.map(p=>[p.id,p.name]))}${field('Data','date','date',`value="${today()}"`)}<div class="field-row">${field('Quantidade boa','goodQty','number','step="1" min="0"')}${field('Custo total do lote','totalCost','number','step="0.01" min="0"')}</div>`,fd=>{const b={id:uid(),productId:fd.get('productId'),date:fd.get('date'),goodQty:Number(fd.get('goodQty')),totalCost:Number(fd.get('totalCost'))};data.batches.push(b);const p=data.products.find(x=>x.id===b.productId);if(p){p.stock+=b.goodQty;p.cost=b.goodQty?b.totalCost/b.goodQty:p.cost;}}); }
function openFailureForm(){ if(!data.products.length) return alert('Cadastre um produto primeiro.'); openModal('Registrar falha',`${select('Produto','productId',data.products.map(p=>[p.id,p.name]))}${field('Data','date','date',`value="${today()}"`)}<div class="field-row">${field('Quantidade perdida','qty','number','step="1" min="1"')}${field('Custo da perda','cost','number','step="0.01" min="0"')}</div>${select('Motivo','reason',[['Peça soltou da mesa','Peça soltou da mesa'],['Entupimento do bico','Entupimento do bico'],['Falha de energia','Falha de energia'],['Configuração incorreta','Configuração incorreta'],['Outro','Outro']])}`,fd=>data.failures.push({id:uid(),productId:fd.get('productId'),date:fd.get('date'),qty:Number(fd.get('qty')),cost:Number(fd.get('cost')),reason:fd.get('reason')})); }
function openOrderForm(){ openModal('Nova encomenda',`${field('Cliente','customer')}${field('Produto ou descrição','product')}${field('Prazo','due','date',`value="${today()}"`)}<div class="field-row">${field('Valor total','total','number','step="0.01" min="0"')}${field('Valor recebido','paid','number','step="0.01" min="0"')}</div>${select('Status','status',[['Orçamento','Orçamento'],['Aguardando pagamento','Aguardando pagamento'],['Em produção','Em produção'],['Em acabamento','Em acabamento'],['Pronto','Pronto'],['Entregue','Entregue']])}`,fd=>data.orders.push({id:uid(),customer:fd.get('customer'),product:fd.get('product'),due:fd.get('due'),total:Number(fd.get('total')),paid:Number(fd.get('paid')),status:fd.get('status')})); }
function openTransactionForm(){ openModal('Nova movimentação',`${select('Tipo','type',[['entrada','Entrada / venda'],['saida','Saída / despesa']])}${field('Descrição','description')}${field('Data','date','date',`value="${today()}"`)}${field('Valor','value','number','step="0.01" min="0"')}`,fd=>data.transactions.push({id:uid(),type:fd.get('type'),description:fd.get('description'),date:fd.get('date'),value:Number(fd.get('value'))})); }
function productName(id){ return data.products.find(p=>p.id===id)?.name || 'Produto'; }
function exportData(){ const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`organiza3d-backup-${today()}.json`;a.click();URL.revokeObjectURL(a.href); }
function importData(e){ const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{data={...defaultData,...JSON.parse(r.result)};saveData();alert('Backup importado.');}catch{alert('Arquivo inválido.');}};r.readAsText(f); }

if('serviceWorker' in navigator){ window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(console.error)); }
render();
