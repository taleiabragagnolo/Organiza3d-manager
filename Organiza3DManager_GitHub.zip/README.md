# Organiza 3D Manager

PWA de uso interno da **Organiza 3D Home e Kids** para controle de:

- investimentos e impressoras;
- filamentos e acessórios;
- produtos e estoque;
- produção por lotes;
- falhas e desperdícios;
- encomendas;
- entradas, despesas, lucro e recuperação do investimento.

## Publicar pelo GitHub Pages

1. Crie um repositório vazio no GitHub.
2. Extraia este pacote no seu aparelho ou computador.
3. Envie **todos os arquivos e pastas** para a raiz do repositório, inclusive a pasta `.github`.
4. Use a branch `main`.
5. No repositório, abra **Settings → Pages**.
6. Em **Build and deployment**, selecione **GitHub Actions**.
7. Aguarde a execução chamada **Publicar no GitHub Pages**.

O endereço será semelhante a:

`https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`

## Instalar no iPhone ou iPad

1. Abra o endereço publicado no Safari.
2. Toque em **Compartilhar**.
3. Escolha **Adicionar à Tela de Início**.

## Armazenamento e backup

Os dados ficam salvos localmente no navegador do aparelho. Use a função de exportação de backup do aplicativo regularmente.

## Estrutura

- `index.html`: tela principal;
- `app.js`: funcionalidades e cálculos;
- `styles.css`: aparência;
- `manifest.json`: configuração de instalação PWA;
- `sw.js`: funcionamento offline;
- `icons/`: ícones do aplicativo;
- `.github/workflows/pages.yml`: publicação automática no GitHub Pages.
